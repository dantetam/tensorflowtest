Dante Tam
26282180
CS189 HW6

My Kaggle username is dantetam.
My code is a standard ipython/Jupyter notebook.
All data should be in a folder of the same level of the ipynb file named hw6_data_dist.