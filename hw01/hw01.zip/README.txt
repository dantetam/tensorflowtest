Dante Tam
26282180
The code is an iPython/Jupyter notebook. Run all the cells from top to bottom.