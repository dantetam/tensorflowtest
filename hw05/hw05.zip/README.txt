Dante Tam
26282180
CS189 HW5

My Kaggle username is dantetam.
My code is a standard ipython/Jupyter notebook.
CSV and MAT files should be in the same directory as the ipynb, while the spam "dist" folder should be in same directory.