Dante Tam
26282180
CS189 HW7

My code is a standard ipython/Jupyter notebook.
All data should be in folders of the same level of the ipynb file named low-rank_data and mnist_data.